import {Link} from "react-router-dom";
export default function Header(){
    return(
        <>
        <nav>
        <ul className="Robin">
            <div>
            <Link to="/"><h5 className="abcd">Home</h5></Link>
            </div>
            <div>
            <Link to="/oferta"><h5 className="abc">Ofertas</h5></Link>
            </div>
            <div>
            <Link to="/produtos"><h5 className="abc">Produtos</h5></Link>
            </div>
        </ul>
        </nav>
        </>
    )
}