import {Link} from "react-router-dom";
export default function Footer(){
    return(
        <>
        <nav>
        <ul className="Nami">
            <Link to="https://www.google.com/search?q=autoajuda&oq=autoajuda&gs_lcrp=EgZjaHJvbWUyBggAEEUYOdIBCDQ4NzZqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8">
                <h5  className="efgh">Ajuda</h5>
            </Link>
            <Link to="https://www.google.com/search?q=acessibilidade&oq=acessebili&gs_lcrp=EgZjaHJvbWUqDwgBEAAYChiDARixAxiABDIGCAAQRRg5Mg8IARAAGAoYgwEYsQMYgAQyDwgCEAAYChiDARixAxiABDIPCAMQABgKGIMBGLEDGIAEMgkIBBAAGAoYgAQyCQgFEAAYChiABDIJCAYQABgKGIAEMgkIBxAAGAoYgAQyCQgIEAAYChiABDIJCAkQABgKGIAE0gEIODU4OWowajmoAgiwAgE&sourceid=chrome&ie=UTF-8">
                <h5  className="efg">Acessibilidade</h5>
            </Link>
            <Link to="https://www.google.com/search?q=leis+brasileiras&oq=leis+brasileiras&gs_lcrp=EgZjaHJvbWUqBwgAEAAYgAQyBwgAEAAYgAQyBwgBEAAYgAQyBwgCEAAYgAQyBwgDEAAYgAQyBwgEEAAYgAQyBwgFEAAYgAQyBwgGEAAYgAQyBwgHEAAYgAQyBwgIEAAYgAQyBwgJEAAYgATSAQg0Mzg5ajBqOagCCLACAQ&sourceid=chrome&ie=UTF-8">
                <h5  className="efg">Politica de Segurança</h5>
            </Link>
        </ul>
        </nav>
        </>
    )
}