import {useState} from "react";
import Header  from "../Header";
import ListaProduto from "../ListaProdutos";
import Carousel from "../Carrosel";
import Footer from "../Footer";

export default function Produtos() { 
    const [ListaProdutos] = useState([
      { id: 600, nome: 'Água-Viva', preco:'R$24,99', imagem:'src/Imagens/aguaviva.webp', artista:'Desconhecido', desconto: "10%"},
      { id: 700, nome: 'Charmander', preco:'R$25,00', imagem:'src/Imagens/char.png', artista:'Desconhecido', desconto: "50%"},
      { id: 800, nome: 'Dragão', preco:'R$10,00',imagem:'src/Imagens/dragao.jpg', artista:'Desconhecido', desconto: "20%"},
      { id: 900, nome: 'Freddy', preco:'R$34,80', imagem:'src/Imagens/frederico.png', artista:'Desconhecido', desconto: "5%"},
      { id: 110, nome: 'Homem', preco:'R$24,00', imagem:'src/Imagens/homem.png', artista:'Desconhecido', desconto: "10%"},  
      { id: 120, nome: 'Kirby', preco:'R$35,50', imagem:'src/Imagens/kirby.jpg', artista:'Desconhecido', desconto: "50%"},
      { id: 130, nome: 'Mangle', preco:'R$12,55', imagem:'src/Imagens/lego.png', artista:'Desconhecido', desconto: "30%"},
      { id: 140, nome: 'Orca', preco:'R$4,00',imagem:'src/Imagens/orca.webp', artista:'Desconhecido', desconto: "90%%"},
      { id: 150, nome: 'Vaso de Planta', preco:'R$19,99', imagem:'src/Imagens/planta.avif', artista:'Desconhecido', desconto: "10%"},
      { id: 160, nome: 'Saiko', preco:'R$80,40', imagem:'src/Imagens/saiko.png', artista:'Desconhecido', desconto: "35%"},      
    ]);
    return (
      <>
      <Header/>
      <br/>
      <h1 className='meus'>Promoção</h1>
        <Carousel/>
        <br/>
          <ListaProduto lista={ListaProdutos}/>
          <Footer/>
    </>
     );
    }