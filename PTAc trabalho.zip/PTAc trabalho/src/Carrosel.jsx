import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';

export default function carousel(){
    return (
        <div>
        <div className='carrosel'>
        <Carousel className='rodaroda'
                infiniteLoop
                useKeyboardArrows
                autoPlay
                showArrows={true}
                showStatus={false}  
                showThumbs={false}
                dynamicHeight>
                    <div>
                    <img src='src/Imagens/carrosel1.png'/>
                    </div>
                    <div>
                    <img src='src/Imagens/carrosel2.png'/>
                    </div>
                    <div>
                    <img src='src/Imagens/carrosel3.jpg'/>
                    </div>
            </Carousel>
            </div>  
            </div>
    )
}
